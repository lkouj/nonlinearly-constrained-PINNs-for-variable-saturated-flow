import sys
import torch
from collections import OrderedDict
# from plotting import newfig, savefig
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from scipy.interpolate import griddata
import matplotlib.gridspec as gridspec
from pyDOE import lhs
import pandas as pd
import itertools
import time
import random
import warnings
import math
warnings.filterwarnings('ignore')
# CUDA support
if torch.cuda.is_available():
    device = torch.device('cuda')
    print('GPU')
else:
    device = torch.device('cpu')
    print('CPU')
def MLinear(in_features, out_features):
    weight = torch.nn.Parameter(torch.Tensor(out_features, in_features)).to(device)
    bias = torch.nn.Parameter(torch.Tensor(out_features)).to(device)
    #std = gain * sqrt(6 / fan_in + fan_out)
    torch.nn.init.xavier_uniform_(weight, gain=0.57735)
    torch.nn.init.zeros_(bias)
    return weight, bias
# the deep neural network
class DNN(torch.nn.Module):
    def __init__(self, layers):
        super(DNN, self).__init__()
        self.depth = len(layers) - 1
        self.activation_tanh = torch.nn.Tanh
        layer_list = list()
        for i in range(self.depth - 1):
            layer_list.append(('layer_%d' % i, torch.nn.Linear(layers[i], layers[i + 1])))
            layer_list.append(('activation_%d' % i, self.activation_tanh()))
        layer_list.append(('layer_%d' % (self.depth - 1), torch.nn.Linear(layers[-2], layers[-1])))
        layerDict = OrderedDict(layer_list)
        # deploy layers
        self.layers = torch.nn.Sequential(layerDict)
        # xavier_initialize
        for each_layer in self.layers:
            if isinstance(each_layer, torch.nn.Linear):
                torch.nn.init.xavier_uniform_(each_layer.weight, gain=1)
                torch.nn.init.zeros_(each_layer.bias)
        print('xavier_initialize_done')
    def forward(self, x):
        out = self.layers(x)
        return out
# the physics-guided neural network
class PhysicsInformedNN():
    def __init__(self, X_star_net,
                 X_train, theta_train,
                 theta_layers,k_layers,psi_layers,
                 X_rre,lb, ub,
                 display_net,
                 X_train_dense,theta_train_dense):
        # boundary conditions
        self.lb = torch.tensor(lb).float().to(device)
        self.ub = torch.tensor(ub).float().to(device)
        self.z_star = torch.tensor(X_star_net[:, 0:1],dtype=torch.float, requires_grad=True).float().to(device)
        self.t_star = torch.tensor(X_star_net[:, 1:2],dtype=torch.float, requires_grad=True).float().to(device)
        # data
        self.z = torch.tensor(X_train[:, 0:1],dtype=torch.float, requires_grad=True).float().to(device)
        self.t = torch.tensor(X_train[:, 1:2],dtype=torch.float, requires_grad=True).float().to(device)
        self.theta = torch.tensor(theta_train, requires_grad=True).float().to(device)
        self.z_dense = torch.tensor(X_train_dense[:, 0:1], dtype=torch.float, requires_grad=True).float().to(device)
        self.t_dense = torch.tensor(X_train_dense[:, 1:2], dtype=torch.float, requires_grad=True).float().to(device)
        self.theta_dense = torch.tensor(theta_train_dense, requires_grad=True).float().to(device)
        self.z_rre = torch.tensor(X_rre[:, 0:1],dtype=torch.float, requires_grad=True).float().to(device)
        self.t_rre = torch.tensor(X_rre[:, 1:2],dtype=torch.float, requires_grad=True).float().to(device)
        self.z_display = torch.tensor(display_net[:, 0:1],dtype=torch.float, requires_grad=True).float().to(device)
        self.t_display = torch.tensor(display_net[:, 1:2],dtype=torch.float, requires_grad=True).float().to(device)
        # deep neural networks
        self.psi_nn=DNN(theta_layers).to(device)
        self.k_weights_0, self.k_biases_0 = MLinear(1, 10)
        self.k_weights_1, self.k_biases_1 = MLinear(10, 1)
        self.theta_weights_0, self.theta_biases_0 = MLinear(1, 10)
        self.theta_weights_1, self.theta_biases_1 = MLinear(10, 1)
        self.k_weights_0 = torch.nn.Parameter(self.k_weights_0)
        self.k_biases_0 = torch.nn.Parameter(self.k_biases_0)
        self.k_weights_1 = torch.nn.Parameter(self.k_weights_1)
        self.k_biases_1 = torch.nn.Parameter(self.k_biases_1)
        self.theta_weights_0 = torch.nn.Parameter(self.theta_weights_0)
        self.theta_biases_0 = torch.nn.Parameter(self.theta_biases_0)
        self.theta_weights_1 = torch.nn.Parameter(self.theta_weights_1)
        self.theta_biases_1 = torch.nn.Parameter(self.theta_biases_1)
        self.psi_nn.register_parameter('k_weights_0', self.k_weights_0)
        self.psi_nn.register_parameter('k_biases_0', self.k_biases_0)
        self.psi_nn.register_parameter('k_weights_1', self.k_weights_1)
        self.psi_nn.register_parameter('k_biases_1', self.k_biases_1)
        self.psi_nn.register_parameter('theta_weights_0', self.theta_weights_0)
        self.psi_nn.register_parameter('theta_biases_0', self.theta_biases_0)
        self.psi_nn.register_parameter('theta_weights_1', self.theta_weights_1)
        self.psi_nn.register_parameter('theta_biases_1', self.theta_biases_1)
        self.alpha = torch.nn.Parameter(torch.tensor(8.8, requires_grad=True).float().to(device))
        self.n = torch.nn.Parameter(torch.tensor(8.8, requires_grad=True).float().to(device))
        self.ks_sqr = torch.nn.Parameter(torch.tensor(8.8, requires_grad=True).float().to(device))
        self.psi_nn.register_parameter('alpha', self.alpha)
        self.psi_nn.register_parameter('n', self.n)
        self.psi_nn.register_parameter('ks_sqr', self.ks_sqr)
        self.theta_r = theta_r
        self.theta_s = theta_s
        # Prevent calculation errors caused by zero denominator
        self.theta_s_fake = + (theta_s - theta_r) / 98 + theta_s
        self.theta_r_fake = - (theta_s - theta_r) / 98 + theta_r
        self.optimizer = torch.optim.LBFGS(
            self.psi_nn.parameters(),
            lr=1.0,
            max_iter=50000,
            max_eval=50000,
            history_size=50,
            tolerance_grad=1e-5,
            tolerance_change=1.0 * np.finfo(float).eps,
            line_search_fn="strong_wolfe"  # can be "strong_wolfe"
        )
        self.iter = 0
        self.optimizer_Adam = torch.optim.Adam(self.psi_nn.parameters(), lr=0.0005, betas=(0.9, 0.999), eps=1e-8,weight_decay=1e-6)
    def psi_net(self, z, t):
        X = torch.cat([z, t], dim=1)
        psi = -torch.exp(self.psi_nn(X))
        return psi
    def k_net(self, X):
        ks=self.ks_sqr**2
        Se = (X-self.theta_r_fake)/(self.theta_s_fake-self.theta_r_fake)
        k=ks* Se ** 0.5 * ((1-(1-(Se)**(1/(1-1/self.n)))**(1-1/self.n))**2)
        return k
    def k_net_dense(self, X):
        k = torch.nn.functional.linear(X, self.k_weights_0 ** 2, self.k_biases_0)
        k = torch.nn.functional.linear(k, self.k_weights_1 ** 2, self.k_biases_1)
        k = torch.exp(k)
        return k
    def theta_net_dense(self, X):
        theta = torch.nn.functional.linear(X, self.theta_weights_0 ** 2, self.theta_biases_0)
        theta = torch.nn.functional.linear(theta, self.theta_weights_1 ** 2, self.theta_biases_1)
        theta = torch.sigmoid(theta) * (self.theta_s - self.theta_r) + self.theta_r
        return theta
    def RRE_net(self, z, t):
        psi = self.psi_net(z, t)
        psi_log10 = torch.log10(-psi)
        theta = self.theta_net_dense(-psi_log10)
        k = self.k_net(theta)
        return theta, k, psi
    def RRE_net_dense(self, z, t):
        psi = self.psi_net(z, t)
        psi_log10 = torch.log10(-psi)
        theta = self.theta_net_dense(-psi_log10)
        k = self.k_net_dense(-psi_log10)
        return theta, k, psi
    def f_net(self, z, t):
        theta, k, psi = self.RRE_net(z, t)
        theta_t = torch.autograd.grad(
            theta, t,
            grad_outputs=torch.ones_like(theta),
            retain_graph=True,
            create_graph=True
        )[0]
        psi_z = torch.autograd.grad(
            psi, z,
            grad_outputs=torch.ones_like(psi),
            retain_graph=True,
            create_graph=True
        )[0]
        psi_zz = torch.autograd.grad(
            psi_z, z,
            grad_outputs=torch.ones_like(psi_z),
            retain_graph=True,
            create_graph=True
        )[0]
        k_z = torch.autograd.grad(
            k, z,
            grad_outputs=torch.ones_like(k),
            retain_graph=True,
            create_graph=True
        )[0]
        f = theta_t - k_z * psi_z - k * psi_zz - k_z
        return theta_t, psi_z, psi_zz, k_z, f
    def f_net_dense(self, z, t):
        theta, k, psi = self.RRE_net_dense(z, t)
        theta_t = torch.autograd.grad(
            theta, t,
            grad_outputs=torch.ones_like(theta),
            retain_graph=True,
            create_graph=True
        )[0]
        psi_z = torch.autograd.grad(
            psi, z,
            grad_outputs=torch.ones_like(psi),
            retain_graph=True,
            create_graph=True
        )[0]
        psi_zz = torch.autograd.grad(
            psi_z, z,
            grad_outputs=torch.ones_like(psi_z),
            retain_graph=True,
            create_graph=True
        )[0]
        k_z = torch.autograd.grad(
            k, z,
            grad_outputs=torch.ones_like(k),
            retain_graph=True,
            create_graph=True
        )[0]
        f = theta_t - k_z * psi_z - k * psi_zz - k_z
        return theta_t, psi_z, psi_zz, k_z, f
    def loss_function(self, z, t, z_rre, t_rre):
        self.theta_pred, self.k_pred, self.psi_pred = self.RRE_net(z, t)
        theta_t_pred, psi_z_pred, psi_zz_pred, k_z_pred, f_pred = self.f_net(z_rre, t_rre)
        loss_theta = torch.mean((self.theta - self.theta_pred) ** 2) * theta_lamda
        loss_RRE = torch.mean(f_pred ** 2) * rre_lamda
        loss = loss_theta + loss_RRE
        return loss
    def loss_function_dense(self, z, t, z_rre, t_rre):
        self.theta_pred, self.k_pred, self.psi_pred = self.RRE_net_dense(z, t)
        theta_t_pred, psi_z_pred, psi_zz_pred, k_z_pred, f_pred = self.f_net_dense(z_rre, t_rre)
        loss_theta = torch.mean((self.theta_dense - self.theta_pred) ** 2) * theta_lamda
        loss_RRE = torch.mean(f_pred ** 2) * rre_lamda
        loss = loss_theta + loss_RRE
        return loss
    def loss_func_LBFGS(self):
        loss = self.loss_function(self.z, self.t,
                                  self.z_rre, self.t_rre)
        self.optimizer.zero_grad()
        loss.backward()
        self.iter += 1
        if self.iter % 1 == 0:
            print(self.iter, '======', loss.item())
        return loss
    def train(self, nIter):
        self.psi_nn.train()
        start_time = time.time()
        for epoch in range(nIter):
            loss = self.loss_function(self.z, self.t,
                                      self.z_rre, self.t_rre)
            self.optimizer_Adam.zero_grad()
            loss.backward()
            self.optimizer_Adam.step()
            if epoch % 1000 == 0:
                elapsed = time.time() - start_time
                print(epoch, '-----', loss.item(), '-----', elapsed)
                print(self.n, self.alpha, self.ks_sqr)
                start_time = time.time()
        # self.optimizer.step(self.loss_func_LBFGS)
        print(self.n, self.alpha, self.ks_sqr)
    def train_dense(self, nIter):
        self.psi_nn.train()
        start_time = time.time()
        for epoch in range(nIter):
            loss = self.loss_function_dense(self.z_dense, self.t_dense, self.z_rre, self.t_rre)
            self.optimizer_Adam.zero_grad()
            loss.backward()
            self.optimizer_Adam.step()
            if epoch % 1000 == 0:
                elapsed = time.time() - start_time
                print(epoch, '-----', loss.item(), '-----', elapsed)
                start_time = time.time()
    def predict(self, X):
        z = torch.tensor(X[:, 0:1], requires_grad=True).float().to(device)
        t = torch.tensor(X[:, 1:2], requires_grad=True).float().to(device)
        self.psi_nn.eval()
        theta_pred, k_pred, psi_pred = self.RRE_net(z, t)
        return theta_pred, k_pred, psi_pred
    def WRC_HCF(self, X):
        WRCs = self.theta_net_dense(X)
        HCFs = self.k_net(WRCs)
        return WRCs, HCFs
    def parameters_choose(self):
        # A series of known soil parameters, if not available, can be used as provided by the author
        data = pd.read_csv("your filr path")
        data_nd = data.values
        n = 0
        alpha = 0
        ks_sqr = 0
        loss = torch.tensor(99999.9).to(device)
        for row in data_nd:
            self.psi_nn.n.data = torch.tensor(row[6]).to(device)
            self.psi_nn.alpha.data = torch.tensor(row[8]).to(device)
            self.psi_nn.ks_sqr.data = torch.tensor((row[9] / scale) ** 0.5).to(device)
            theta_t_pred, psi_z_pred, psi_zz_pred, k_z_pred, f_pred = self.f_net(self.z_rre, self.t_rre)
            loss_RRE = torch.mean(f_pred ** 2)
            print(self.n, self.alpha, self.ks_sqr, "---loss---", loss_RRE)
            if loss_RRE < loss:
                row_mark = row
                loss = loss_RRE
                print("---parameters have been chnanged---")

        self.psi_nn.n.data = torch.tensor(row_mark[6]).to(device)
        self.psi_nn.alpha.data = torch.tensor(row_mark[8]).to(device)
        self.psi_nn.ks_sqr.data = torch.tensor((row_mark[9] / scale) ** 0.5).to(device)


        # If you have a good estimate, it can also be directly used as the initial value of the parameter
        # When comparing with HYDRUS-1D, we used the same initial values for optimization to ensure fairness in the comparison

        # self.psi_nn.n.data = torch.tensor(4.42).to(device)
        # self.psi_nn.alpha.data = torch.tensor(3.4).to(device)
        # self.psi_nn.ks_sqr.data = torch.tensor((14.3/scale)**0.5).to(device)

# Used to generate distribution points
def peidian(lb, ub):
    lhs_re = lhs(2, 8000)
    Z_RE_train = lb + (ub - lb) * lhs_re
    return Z_RE_train
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# Hyperparameters that need to be set
time_length= 2.5/5    # Time_1ength is the total length of time you need to calculate
scale = 5/time_length   # Used for standardization
psi_layers = [2, 20, 20, 20, 20, 20, 20, 1]
k_layers = [1, 10, 1]
theta_layers = [1, 10, 1]
theta_lamda = 10
rre_lamda = 1
seed_list = [21] # Random seed number
noise_list = [0]
theta_r = 0.045 # If not, it can be roughly estimated. According to existing research results, this parameter does not have a significant impact on the results
theta_s = 0.430 # If not, you can take the highest moisture content value in the dataset

for noise in noise_list:
    for seed in seed_list:
        setup_seed(seed)
        # STEP1
        data_dense = pd.read_csv("your_file_path")  # Remember to change the path
        t_star_dense = data_dense['time'].values[:, None]
        z_star_dense = data_dense['depth'].values[:, None]
        theta_star_dense = data_dense['theta'].values[:, None]
        X_train_dense = np.hstack((z_star_dense, t_star_dense))

        # The selection of data points needs to be specifically determined based on the division of local regions
        fixed_list_p = [0, 1, 2]
        for i in range(251):
            if i == 0:
                fixed_list = fixed_list_p
            else:
                fixed_list_plus = [each + 5 * i for each in fixed_list_p]
                fixed_list = np.append(fixed_list, fixed_list_plus)
        # noise
        noise_theta_dense = noise * np.random.randn(theta_star_dense.shape[0], theta_star_dense.shape[1])
        theta_noise_dense = theta_star_dense + noise_theta_dense
        X_train_dense = X_train_dense[fixed_list, :]
        theta_train_dense = theta_noise_dense[fixed_list, :]

        # STEP2
        data = pd.read_csv("your_file_path")  # Remember to change the path
        t_star = data['time'].values[:, None]
        z_star = data['depth'].values[:, None]
        theta_star = data['theta'].values[:, None]
        X_star = np.hstack((z_star, t_star))

        # The selection of data points needs to be specifically determined based on the division of local regions
        fixed_list_p = [0, 1, 2]
        for i in range(251):
            if i == 0:
                fixed_list = fixed_list_p
            else:
                fixed_list_plus = [each + 5 * i for each in fixed_list_p]
                fixed_list = np.append(fixed_list, fixed_list_plus)
        # noise
        noise_theta = noise * np.random.randn(theta_star.shape[0], theta_star.shape[1])
        theta_noise = theta_star + noise_theta
        X_train = X_star[fixed_list, :]
        theta_train = theta_noise[fixed_list, :]

        # We need a series of spatiotemporal coordinates here to output your prediction results
        data_net = pd.read_csv("your_file_path")
        t_net = data_net['time'].values[:, None]
        z_net = data_net['depth'].values[:, None]
        X_net_display = np.hstack((z_net, t_net))

        # Used to determine the generated area for matching points
        lb = X_net_display.min(0)
        ub = X_net_display.max(0)
        # lb = np.array([-1, 0])
        # ub = np.array([0, 5])
        X_re_train = peidian(lb, ub)

        model = PhysicsInformedNN(X_star,
                                  X_train, theta_train,
                                  psi_layers, k_layers, theta_layers,
                                  X_re_train, lb, ub,
                                  X_net_display,
                                  X_train_dense, theta_train_dense)

        # Training steps for step1
        # model.optimizer_Adam = torch.optim.Adam(model.psi_nn.parameters(), lr=0.005, betas=(0.9, 0.999), eps=1e-8,weight_decay=3e-5)
        model.train_dense(20000)
        model_save_load = "model output path"
        torch.save(model, model_save_load)

        # Training steps for step2
        # model.optimizer_Adam = torch.optim.Adam(model.psi_nn.parameters(), lr=0.0005, betas=(0.9, 0.999), eps=1e-8,weight_decay=3e-6)
        model.parameters_choose()
        model.train(50000)
        model_save_load = "model output path"
        torch.save(model, model_save_load)

        theta_pred, k_pred, psi_pred = model.predict(X_net_display)
        theta_t_pred, psi_z_pred, psi_zz_pred, k_z_pred, f_pred = model.f_net(model.z_display, model.t_display)
        flux_pred = -k_pred * (psi_z_pred + 1)

        z_net_display = X_net_display[:, 0:1]
        t_net_display = X_net_display[:, 1:2]

        dataset_result = pd.DataFrame({'z': z_net_display.flatten(),
                                       't': t_net_display.flatten(),
                                       'psi_pred': psi_pred.detach().cpu().numpy().flatten(),
                                       'theta_pred': theta_pred.detach().cpu().numpy().flatten(),
                                       'K_pred': k_pred.detach().cpu().numpy().flatten(),
                                       'theta_t_pred': theta_t_pred.detach().cpu().numpy().flatten(),
                                       'psi_z_pred': psi_z_pred.detach().cpu().numpy().flatten(),
                                       'psi_zz_pred': psi_zz_pred.detach().cpu().numpy().flatten(),
                                       'k_z_pred': k_z_pred.detach().cpu().numpy().flatten(),
                                       'f_pred': f_pred.detach().cpu().numpy().flatten(),
                                       'flux_pred': flux_pred.detach().cpu().numpy().flatten()})

        data_rre_load = "Path to CSV file"
        dataset_result.to_csv(data_rre_load)

        psi_log10 = torch.arange(-5, 3.5, 0.02).to(device)
        psi_log10 = psi_log10.view([len(psi_log10), 1])
        psi = -10 ** (psi_log10.detach().cpu().numpy())
        WRCs, HCFs = model.WRC_HCF(-psi_log10)

        dataset_cons = pd.DataFrame({'psi': psi.flatten(),
                                     'theta': WRCs.detach().cpu().numpy().flatten(),
                                     'k': HCFs.detach().cpu().numpy().flatten(),
                                     '-log[-psi]': -psi_log10.detach().cpu().numpy().flatten()})

        # Note: The HCFs here may have been scaled by a factor of scale due to your standardization, and you will need to restore them when viewing them later
        data_rre_load = "Path to CSV file"
        dataset_cons.to_csv(data_rre_load)


